<h1>PVR switch timer aka PVR reminder</h1>

Original made by Birger Jesch
https://github.com/b-jesch/service.kn.switchtimer

<h1>Addon para lembretes no Kodi</h1>

Permite criar até 10 lembretes para no PVR do kodi.

